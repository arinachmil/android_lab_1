# TSN_ANDROID_DEMO_HELLO
Простейшая программа суммы двух цифр на Android

![Screenshot](screenshot.png)

https://www.youtube.com/watch?v=PMYmKEhbh0s
